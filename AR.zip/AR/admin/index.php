<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Login Modal Form</title>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width" />
    <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.14.0/css/all.min.css'>
    <link rel='stylesheet' href='//maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css'>
    <link rel="stylesheet" href="style.css" />
  </head>
  <body>
<button class="login-button" href="#" data-target="#login" data-toggle="modal">Login</button>
<div id="login" class="modal fade" role="dialog">
  <div class="container">
    <div class="form-container sign-in-container">
      <form action="index_query.php" method="post">
        <h1>Sign in</h1>
        <div class="social-container">
          <a href="#" class="social"><i class="fab fa-facebook-f"></i></a>
          <a href="#" class="social"><i class="fab fa-google-plus-g"></i></a>
          <a href="#" class="social"><i class="fab fa-linkedin-in"></i></a>
        </div>
        <span>or use your account</span>
        <input name="email" type="username" placeholder="Email" />
        <input name="password" type="password" placeholder="Password" />
        <a href="#">Forgot your password?</a>
        <input class="send" type="submit" name="submit" value="Sign In">
      </form>
    </div>
  </div>
</div>
<script src='//cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
<script src='//maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js'></script>
  </body>
</html>