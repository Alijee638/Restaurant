<?php

include("connection.php");

$id = $_GET['id'];

$name = $_GET['name'];
$pera = $_GET['pera'];
$price = $_GET['price'];

$query = "UPDATE `main_dishes` SET `name`='$name',`pera`='$pera',`price`='$price' WHERE id = '$id'";

$q = mysqli_query($con,$query);

if($q){
    header("location:main_dishes.php");
}

else{
    echo"error";
}


?>