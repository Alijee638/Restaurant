<?php

include("connection.php");

$id = $_post['id']; 

$name = $_POST['name'];
$pera = $_POST['pera'];
$price = $_POST['price'];


if($_FILES["new_img"]["name"] != '') {
    $file_name = $_FILES["new_img"]["name"];
    $file_temp = $_FILES["new_img"]["tmp_name"];
    $path = "C:/xampp/htdocs/medicare/admin/imgs/" . $file_name; 
    move_uploaded_file($file_temp, $path);
    
    
    $old_img = $_POST['old_img'];
    unlink("C:/xampp/htdocs/medicare/admin/imgs/" . $old_img);
    
    $query = "UPDATE `deserts` SET `name`='$name',`pera`='$pera',`price`='$price', `img`='$file_name' WHERE id = '$id'";
} else {
    
    $query = "UPDATE `deserts` SET `name`='$name',`pera`='$pera',`price`='$price' WHERE id = '$id'";
}

$q = mysqli_query($con, $query);

if($q){
    header("location:deserts.php");
} else {
    echo "Error: Update failed!";
}

?>
