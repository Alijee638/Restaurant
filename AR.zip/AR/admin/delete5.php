<?php

include("connection.php");

$id = $_GET['id'];

$sql = "DELETE FROM `booking` WHERE id = '$sql'";

$query = mysqli_query("$con,$sql");

if($query){
    header("location:booking.php");
}
else{
    echo"error";
}

?>