
<?php
include("connection.php");

$id = $_GET['id'];
$name = $_GET['name'];
$pera = $_GET['pera'];

$query = "UPDATE `shaif` SET `name`='$name', `pera`='$pera' WHERE id='$id'";

$q = mysqli_query($con, $query);

if($q){
    header("location:shaif.php");
} else {
    echo "خرابی: " . mysqli_error($con);
}
?>
