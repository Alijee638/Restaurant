<?php
// include("connection.php");

// if(!empty($_POST['submit'])){

//     $name = $_POST['name'];

//     $pera = $_POST['pera'];

//     require("/fpdf/fpdf.php");

//     $pdf = new FPDF();
//     $pdf->AddPage();
//     $pdf-> SetFont("Arial","",16);
//     $pdf-> Cell(0,10,"Registration Detalis",1,1,"C");
//     $pdf-> Cell(50,10,"Chief Name",1,0);
//     $pdf-> Cell(50,10,"Details",1,1);

//     $pdf-> Cell(50,10,$name,1,0);
//     $pdf-> Cell(50,10,$pera,1,0);
//     $pdf->output();

// }

include("connection.php");


if(isset($_GET['id'])) {
    $id = $_GET['id'];

    $query = "SELECT * FROM `shaif` WHERE `id` = '$id'";
    $result = mysqli_query($con, $query);
    $row = mysqli_fetch_assoc($result);

    require("C:\\xampp\\htdocs\\AR\\fpdf\\fpdf.php");


    $pdf = new FPDF();
    $pdf->AddPage();
    $pdf->SetFont("Arial", "b", 16);
    $pdf->Cell(0, 10, "Registration Details", 1, 1, "C");
    $pdf->Cell(40, 10, "Chief Name", 1, 0);
    $pdf->Cell(0, 10, "Details", 1, 1 ,"C");

    $pdf->Cell(40, 20, $row['name'], 1, 0,"C");
    // $pdf->Cell(0, 10, $row['pera'], 1,0);

    $pdf->MultiCell(0, 10, $row['pera'], 1,0);


    $pdf->Output();
    exit();
} else {
    echo "Invalid ID";
}



?>
