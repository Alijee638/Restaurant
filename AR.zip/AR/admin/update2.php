<?php

include("connection.php");

$id = $_GET['id'];

$name = $_GET['name'];
$pera = $_GET['pera'];
$price = $_GET['price'];

$query = "UPDATE `drink` SET `name`='$name',`pera`='$pera',`price`='$price' WHERE id = '$id'";

$q = mysqli_query($con,$query);

if($q){
    header("location:drink.php");
}

else{
    echo"error";
}


?>