<?php

include("connection.php");

$id = $_GET['id'];

$query = "DELETE FROM `starters` WHERE id = '$id'";

$q = mysqli_query($con,$query);

if($q){

    header("location:starters.php");
}

else{

    echo"error";
}


?>





