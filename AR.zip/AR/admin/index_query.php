<?php

$con = mysqli_connect("localhost", "root", "", "hotel");

if(isset($_POST['submit'])){

    $email = $_POST['email'];
    $password = $_POST['password'];

    $query = "SELECT * FROM `login` WHERE email = '$email' AND password ='$password'";
    
    $result = mysqli_query($con, $query);

    $count = mysqli_num_rows($result);

    if($count != 1){
        echo "<script>alert('Incorrect password'); window.location.assign('index.php');</script>";
    } else {
        header("location: welcome.php");
    }
}

?>
