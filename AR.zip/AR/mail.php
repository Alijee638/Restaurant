<?php
                            
$name = $_POST['name'];
$email = $_POST['email'];
$contact = $_POST['contact'];
$person = $_POST['person'];
$date = $_POST['date'];
$time = $_POST['time'];
$preferred = $_POST['preferred'];
$occasion = $_POST['occasion'];
                            
$con = mysqli_connect("localhost","root","","hotel");
$query = "INSERT INTO `booking`(`id`, `name`, `email`, `contact`, `person`, `date`, `time`, `preferred`, `occasion`) VALUES (null,'$name','$email','$contact','$person','$date','$time','$preferred','$occasion')";

$q = mysqli_query($con,$query);

if(!$q){
    echo"<script>alert('incorrect password');window.location.assign('index.php')</script>";  
}
else{
    header("location:index.php");
}                         
                            
?>